package com.example.walmart.domain.usecase

import com.example.walmart.domain.model.Country
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.Arguments
import org.junit.jupiter.params.provider.MethodSource

class SearchCountryUseCaseTest {

    private val searchCountryUseCase = SearchCountryUseCase()

    @ParameterizedTest
    @MethodSource("provideTestCases")
    fun `test SearchCountryUseCase`(query: String, expected: List<Country>, inputList: List<Country>) {
        val result = searchCountryUseCase(inputList, query)
        assertEquals(expected, result)
    }

    companion object {
        @JvmStatic
        fun provideTestCases() = listOf(
            // Case 1: Empty query should return the full list
            Arguments.of(
                "",
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                ),
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                )
            ),
            // Case 2: Query that matches a country's name
            Arguments.of(
                "Ind",
                listOf(Country(name = "India", region = "Asia")),
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                )
            ),
            // Case 3: Query that matches a country's region
            Arguments.of(
                "Europe",
                listOf(Country(name = "Germany", region = "Europe")),
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                )
            ),
            // Case 4: Query with mixed case (case-insensitivity)
            Arguments.of(
                "iND",
                listOf(Country(name = "India", region = "Asia")),
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                )
            ),
            // Case 5: Query that matches both name and region
            Arguments.of(
                "Am",
                listOf(Country(name = "United States", region = "Americas")),
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                )
            ),
            // Case 6: Query that matches nothing
            Arguments.of(
                "Oceania",
                emptyList<Country>(),
                listOf(
                    Country(name = "United States", region = "Americas"),
                    Country(name = "India", region = "Asia"),
                    Country(name = "Germany", region = "Europe")
                )
            )
        )
    }
}