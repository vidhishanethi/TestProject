package com.example.walmart.presentation.details

@RunWith(AndroidJUnit4::class)
class CountryDetailsFragmentTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private val viewModel: CountriesViewModel = mockk(relaxed = true)
    private val stateFlow = MutableStateFlow(
        CountriesViewModel.State(
            loading = false,
            errorMessage = null,
            query = "",
            items = emptyList(),
            originalItems = emptyList()
        )
    )

    @Before
    fun setup() {
        every { viewModel.state } returns stateFlow
        every { viewModel.effectFlow } returns flowOf()
    }

    @Test
    fun testLoadingStateIsDisplayed() {
        stateFlow.value = stateFlow.value.copy(loading = true)
        launchFragment()

        // Assert that the swipeRefreshLayout is refreshing (loading indicator is visible)
        onView(withId(R.id.swipeRefreshLayout)).check(matches(isRefreshing()))
    }

    @Test
    fun testErrorMessageIsDisplayed() {
        val errorMessage = "Network error"
        stateFlow.value = stateFlow.value.copy(errorMessage = errorMessage)
        launchFragment()

        // Verify that a Snackbar with the error message is displayed
        onView(withText(errorMessage)).check(matches(isDisplayed()))
    }

    @Test
    fun testListIsUpdated() {
        val countries = listOf(Country("India", "Asia"), Country("Germany", "Europe"))
        stateFlow.value = stateFlow.value.copy(items = countries)
        launchFragment()

        // Verify that the RecyclerView displays the countries (adapter submission)
        onView(withId(R.id.countryRecyclerView)).check(matches(hasChildCount(countries.size)))
    }

    @Test
    fun testSearchQueryUpdates() {
        launchFragment()
        val query = "Ind"

        onView(withId(R.id.action_search)).perform(typeText(query))

        verify { viewModel.search(query) }
    }

    @Test
    fun testItemClickNavigation() {
        val country = Country("India", "Asia")
        val effectFlow = MutableSharedFlow<CountriesViewModel.Effect>()
        every { viewModel.effectFlow } returns effectFlow

        launchFragment()

        // Simulate item click
        onView(withId(R.id.countryRecyclerView)).perform(
            RecyclerViewActions.actionOnItemAtPosition<CountriesAdapter.ViewHolder>(
                0, click()
            )
        )

        // Verify that the ViewModel sends the appropriate effect
        coVerify { viewModel.onItemClick(country) }
    }

    private fun launchFragment() {
        launchFragmentInContainer<CountriesFragment>(
            themeResId = R.style.Theme_AppCompat
        )
    }

}