package com.example.walmart.presentation.countries

import android.os.Build
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.walmart.presentation.R
import com.example.walmart.presentation.details.CountryDetailsArg
import com.google.common.truth.Truth.assertThat
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.kotlin.verify
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(sdk = [Build.VERSION_CODES.Q])
class CountriesFragmentTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private lateinit var mockNavController: NavController

    @Before
    fun setUp() {
        mockNavController = Mockito.mock(NavController::class.java)
    }

    @Test
    fun whenItemClicked_navigatesToCountryDetailsFragment() {
        // Launch the fragment in a container
        val scenario = launchFragmentInContainer<CountriesFragment>(themeResId = R.style.Theme_AppCompat)

        scenario.onFragment { fragment ->
            Navigation.setViewNavController(fragment.requireView(), mockNavController)
        }

        // Simulate item click
        scenario.onFragment { fragment ->
            val country = Country("USA", "United States", "North America")
            fragment.onItemClick(country)
        }

        // Verify navigation with correct arguments
        verify(mockNavController).navigate(
            R.id.countryDetailsFragment,
            bundleOf(CountryDetailsArg.COUNTRY_CODE to "USA")
        )
    }

    @Test
    fun whenSearchQueryIsEntered_filtersCountries() {
        val scenario = launchFragmentInContainer<CountriesFragment>(themeResId = R.style.Theme_AppCompat)
        scenario.onFragment { fragment ->
            fragment.viewModel.search("USA")
            assertThat(fragment.viewModel.state.value.items).containsExactly(
                Country("USA", "United States", "North America")
            )
        }
    }
}